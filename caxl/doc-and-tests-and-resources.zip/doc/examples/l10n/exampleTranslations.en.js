/**
 * filename:        exampleTranslations.en.js
 *
 * This work is public domain.
 */

{
    "Username:" : "Username:",
    "Password:" : "Password:",
    "Currency is £": "Currency is $",
    "The answer is 42" : "What is the question"
}
