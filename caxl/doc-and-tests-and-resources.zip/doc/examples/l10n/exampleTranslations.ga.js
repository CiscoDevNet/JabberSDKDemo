/**
 * filename:        exampleTranslations.ga.js
 *
 * This work is public domain.
 */

{
    "Username:" : "Ainm Úsáideora:",
    "Password:" : "Focal Faire:",
    "Currency is £": "Airgeadra Is é €",
    "The answer is 42" : "Cad é an cheist"
}
