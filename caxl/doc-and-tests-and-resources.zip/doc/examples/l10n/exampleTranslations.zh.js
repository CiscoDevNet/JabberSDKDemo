/**
 * filename:        exampleTranslations.zh.js
 *
 * This work is public domain.
 */

{
    "Username:" : "用户名:",
    "Password:" : "密码:",
    "Currency is £": "货币是元",
    "The answer is 42" : "答案是42"
}
