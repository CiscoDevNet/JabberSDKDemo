/**
 * filename:        TranslatorData.en.js
 *
 * Portions created or assigned to Cisco Systems, Inc. are
 * Copyright (c) 2009-2011 Cisco Systems, Inc.  All Rights Reserved.
 */

{
    "test key one": "initialised to test key one",
    "test {0} one": "thar be the {0} one"
}