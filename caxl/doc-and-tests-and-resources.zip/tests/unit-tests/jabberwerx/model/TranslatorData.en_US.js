/**
 * filename:        TranslatorData.en_US.js
 *
 * Portions created or assigned to Cisco Systems, Inc. are
 * Copyright (c) 2009-2011 Cisco Systems, Inc.  All Rights Reserved.
 */

{
    "test key one": "This is test key one, YO!",
    "test {0} one": "This be {0} one, YO!"
}