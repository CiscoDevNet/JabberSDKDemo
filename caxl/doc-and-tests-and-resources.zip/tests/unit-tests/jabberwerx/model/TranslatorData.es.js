/**
 * filename:        TranslatorData.es.js
 *
 * Portions created or assigned to Cisco Systems, Inc. are
 * Copyright (c) 2009-2011 Cisco Systems, Inc.  All Rights Reserved.
 */

{
    "test key one": "clave pruebar uno",
    "test {0} one": "{0} pruebar uno"
}