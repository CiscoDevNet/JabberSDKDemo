/**
 * filename:        TranslatorData2.en.js
 *
 * Portions created or assigned to Cisco Systems, Inc. are
 * Copyright (c) 2009-2011 Cisco Systems, Inc.  All Rights Reserved.
 */

{
    "alternate key two": "key two alternate"
}