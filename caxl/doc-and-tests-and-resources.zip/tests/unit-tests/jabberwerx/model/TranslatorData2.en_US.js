/**
 * filename:        TranslatorData2.en_US.js
 *
 * Portions created or assigned to Cisco Systems, Inc. are
 * Copyright (c) 2009-2011 Cisco Systems, Inc.  All Rights Reserved.
 */

{
    "alternate key one": "one alternate key"
}